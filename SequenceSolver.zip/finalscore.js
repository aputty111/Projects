var score = 0;
score = parseInt(localStorage.getItem('pointsVal').trim());

function indexPage() {
  location.replace('index.html');
}

function printScore()
{
  document.getElementById ('print').innerHTML = "YOUR SCORE IS " + score + "/50";
  score = 0;
  localStorage.setItem('pointsVal', score);
}

//We got happy.png from: https://www.kingdavid.org.uk/index.php/blogging-frontpage/reflections
//We got sad.png from: https://app.learninghub.online/gogsatstatics/download/multi/flipbooks/tainos_app1.1/index.html
function displayImage()
{
  if(score >= 30)
  { 
    document.getElementById('image').innerHTML = '<img src="happy.png" alt = "A happy picture" width = "300">';
  }
  else
  {
    document.getElementById('image').innerHTML = '<img src="sad.png" alt = "A sad picture" width = "300">';
  }
}