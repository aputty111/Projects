function indexPage()
{
  location.replace('index.html');
}