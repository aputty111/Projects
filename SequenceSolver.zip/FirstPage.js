function startPage()
{
   location.replace('StartPage.html');

}
function instructionsPage()
{
  location.replace('InstructionsPage.html');
  
}

function getPattern()
{
  var fs = require('fs');

  
}

function arithmeticPage()
{
  location.replace('ArithmeticPage.html');
}

function geometricPage()
{
    location.replace('GeometricPage.html');
}