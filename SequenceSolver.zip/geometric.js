  //A lot of code has concepts covered in the LocalStorage file that we wrote in class

let geoQuestion = [];

let correctAnswer = 0;
var question = 1;
question = parseInt(localStorage.getItem("myValue").trim());
var points = 0;

 points = parseInt(localStorage.getItem("pointsVal").trim());

showPoints();

function getGeoQuestions()
{

  let initial = Math.floor(Math.random()*10)+ 1;
  let increment = Math.floor(Math.random()*10) + 2;

  let i = 0;
  for(i = 0; i<3; i++)
  {
      geoQuestion[i] = initial * Math.pow(increment, i);
  }
  correctAnswer = initial * Math.pow(increment, i);
}

//We used chatgpt generative ai to help us create this function
function shuffleGeoArray(array) 
{
  for (let i = 0; i < array.length; i++) {
    const j = Math.floor(Math.random() * (i + 1));
    let temp = array[i];
    array[i] = array[j];
    array[j] = temp;
  }
}



//We used the Fisher Yates Alogrithm to shuffle the questions.
function printGeoQuestions() 
{
  let answers = [];
  answers[0] = correctAnswer;
  for(let i = 1; i<4; i++)
  {
    answers[i] = correctAnswer + Math.floor(Math.random()*40)+ (-20);
    for(let j = 0; j<i; j++)
      {
        while(answers[i] == answers[j])
          {
            answers[i] = correctAnswer + Math.floor(Math.random()*40)+ (-20);
          }
      }
  }
  shuffleGeoArray(answers);

  let str = "Question: ";
  for (let i = 0; i < geoQuestion.length; i++) {
    str += geoQuestion[i];
    if (i < geoQuestion.length - 1) {
      str += ", ";
    }
  }
  str += ", ?";

  let ans = "";
  for (let i = 0; i < answers.length; i++) {``
    ans += `<label><input type="radio" name="nextgeonum" value="${answers[i]}">${answers[i]}</label>`;
  }

  showGeoQuestions(str, ans);
}

function showGeoQuestions(str,ans) {
  document.getElementById('geoquestions').innerHTML = str;
  document.getElementById('geochoices').innerHTML = ans;
}

function showPoints() {
  if(points == null)
  {
    points = 0;
  }
  document.getElementById('points').innerHTML = "Points: " + points;
}

function checkAnswer()
{
  const elements = document.querySelectorAll('input[name="nextgeonum"]');
  for(const element of elements)
  {
    if(element.checked)
    {
      if(parseInt(element.value) == correctAnswer)
      {
        points += 10;
      }
    }
  }
  showPoints();
}

function showQuestion()
{
  document.getElementById('questionNum').innerHTML = "Question: " + question;
}

function changeQuestion(num)
{
  question += num;
  showQuestion();
}

function goToNextPage(nextPage)
{
  localStorage.setItem("pointsVal", points)
  localStorage.setItem("myValue", question);
  window.location.href=nextPage;
  location.replace(nextPage);
}

function resetQuestion()
{
  question = 1;
  localStorage.setItem("myValue", question);
  localStorage.setItem("pointsVal", points);
}

function reset()
{
  if(question < 5)
  {
    checkAnswer();
    changeQuestion(1);
    goToNextPage("GeometricPage.html");
  }
  else
  {
    checkAnswer();
    resetQuestion();
    goToNextPage('FinalScorePage.html');
  }
}

function indexPage()
{
  location.replace('StartPage.html');
}

function startGeoTimer() 
{
  let geoseconds = 10;

  let geotimerElement = document.getElementById('geotimer');
    geotimerElement.innerHTML = 'Time: ' + geoseconds + 's';
  let timer = setInterval(function () {
      geoseconds--;
      geotimerElement.innerHTML = 'Time: ' + geoseconds + 's';
    if (geoseconds <= 0) 
    {
        geoseconds = 1;
      document.getElementById("geochoices").style.display = "none";
      let nextGeoQues = `<button id = "nextGeoQues" onclick="reset()">Next Question</button>`;
      showGeoButton(nextGeoQues);
    }
  }, 1000);
}

//https://stackoverflow.com/questions/29346385/hide-radio-button-while-keeping-its-functionality
function showGeoButton(nextGeoQues)
{
  document.getElementById('nextgeoques').innerHTML = nextGeoQues;
   document.getElementById("submit").style.display = "none";
}

