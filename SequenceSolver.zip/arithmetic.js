//A lot of code has concepts covered in the LocalStorage file that we wrote in class

let questions = [];
let correctAnswer = 0;


var question = 1;
question = parseInt(localStorage.getItem("myValue2").trim());

var ariPoints = 0;
ariPoints= parseInt(localStorage.getItem("pointsVal").trim());

//showQuestion();
showPoints();

function getQuestions() {
  let initial = Math.floor(Math.random() * 100) + 1;
  let increment = Math.floor(Math.random() * 100) + 1;

  let i = 0;
  for (i = 0; i < 3; i++) {
    questions[i] = initial + increment * i;
  }

  correctAnswer = initial + increment * i;
}

//We used chatgpt to get an idea on how to do this function. This function is used to shuffle the location of the correct answer in in the radio buttons.
function shuffleArray(array) {
  for (let i = 0; i < array.length; i++)
  {
    const j = Math.floor(Math.random() * (i + 1));
    let temp = array[i];
    array[i] = array[j];
    array[j] = temp;
  }
}



//We used the Fisher Yates Alogrithm to shuffle the questions.
function printQuestions() 
{
  let answers = [];
  answers[0] = correctAnswer;
  for(let i = 1; i<4; i++)
  {
    answers[i] = correctAnswer + Math.floor(Math.random()*40)+ (-20);
    for(let j = 0; j<i; j++)
    {
      while(answers[i] == answers[j])
        {
          answers[i] = correctAnswer + Math.floor(Math.random()*40)+ (-20);
        }
    }
  }
  shuffleArray(answers);
  let str = "Question: ";
  for (let i = 0; i < questions.length; i++) {
    str += questions[i];
    if (i < questions.length - 1) {
      str += ", ";
    }
  }
  str += ", ?";

  let ans = "";
  for (let i = 0; i < answers.length; i++) {``
    ans += `<label style="font-size:30px;color:#00008B;"><input type="radio" name="nextarinum" value="${answers[i]}">${answers[i]}</label>`;
  }

  showQuestions(str, ans);
}

function showQuestions(str,ans) {
  document.getElementById('question').innerHTML = str;
  document.getElementById('choices').innerHTML = ans;
}

function showPoints() {
  if(ariPoints == null)
  {
    ariPoints = 0;
  }
  document.getElementById('points').innerHTML = "Points: " + ariPoints;
}

function startPage() {
  location.replace('StartPage.html');
}

function reset() 
{
  if (question < 5)
  {
    checkAriAnswer();
    changeQuestion(1);
    goToNextPage('ArithmeticPage.html');
  } 
  else 
  {
    checkAriAnswer();
    resetQuestion();
    goToNextPage('FinalScorePage.html');
  }
}
//https://stackoverflow.com/questions/60683534/get-value-form-input
function checkAriAnswer()
{
   const elements = document.querySelectorAll('input[name="nextarinum"]');
  for(const element of elements)
  {
    if(element.checked)
    {
      if(parseInt(element.value) == correctAnswer)
      {
        ariPoints += 10;
      }
    }
  }
  
  showPoints();
}

function showQuestion()
{
  document.getElementById('questionNum').innerHTML = "Question: " + question;
}

function changeQuestion(num)
{
  question += num;
  showQuestion();
}

function goToNextPage(nextPage)
{
  localStorage.setItem("pointsVal", ariPoints);
  localStorage.setItem("myValue2", question);
  window.location.href=nextPage;
  location.replace(nextPage);
}

function resetQuestion()
{
  question = 1;
  localStorage.setItem("myValue2", question);
  localStorage.setItem("pointsVal", ariPoints);
}

function startTimer() 
{
  let seconds = 10;
  const elements = document.querySelectorAll('input[name="nextarinum"]');
  let timerElement = document.getElementById('timer');
  timerElement.innerHTML = 'Time: ' + seconds + 's';
  let timer = setInterval(function () {
    seconds--;
    timerElement.innerHTML = 'Time: ' + seconds + 's';
    if (seconds <= 0) {
      seconds = 1;
      resetTimer(timer);
    
        
          document.getElementById("choices").style.display = "none"; 
      
      let nextQues = `<button id = "nextQues" onclick="reset()">Next Question</button>`;
    
      showButton(nextQues);
    }
  }, 1000);
}

function resetTimer(timer)
{
  timer = 0;
}
//https://stackoverflow.com/questions/8557119/making-a-button-invisible-by-clicking-another-button-in-html
function showButton(nextQues)
{
  document.getElementById('nextques').innerHTML = nextQues;
  document.getElementById("submit").style.display = "none";
}
