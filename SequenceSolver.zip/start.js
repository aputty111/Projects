function arithmeticPage()
{
  location.replace('ArithmeticPage.html');
}

function geometricPage()
{
  location.replace('GeometricPage.html');
}

function indexPage()
{
  location.replace('index.html');
}